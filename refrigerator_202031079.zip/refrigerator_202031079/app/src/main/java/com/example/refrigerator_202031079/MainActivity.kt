package com.example.refrigerator_202031079

import com.example.refrigerator_202031079.R
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.provider.MediaStore
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import android.app.DatePickerDialog
import java.util.Calendar
import android.widget.EditText
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import android.app.Activity
import android.graphics.BitmapFactory

class MainActivity : AppCompatActivity(), View.OnClickListener {
    var btnCamera: Button? = null
    var imageView: ImageView? = null
    var currentPhotoPath: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 디자인 정의
        btnCamera = findViewById<View>(R.id.btnPhoto) as Button
        imageView = findViewById<View>(R.id.imageView) as ImageView
        btnCamera!!.setOnClickListener(this)

        val myButton = findViewById<Button>(R.id.button)
        val buttonText = "나만의 냉장고"

// SpannableStringBuilder를 사용하여 텍스트 스타일을 지정합니다.

// SpannableStringBuilder를 사용하여 텍스트 스타일을 지정합니다.
        val builder = SpannableStringBuilder(buttonText)

// 텍스트의 일부를 다른 색상으로 변경합니다.

// 텍스트의 일부를 다른 색상으로 변경합니다.
        val colorSpan = ForegroundColorSpan(Color.GREEN) // 원하는 색상으로 변경하세요.

        builder.setSpan(colorSpan, 0, -3, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE) // 첫 5글자를 다른 색상으로 지정


// 버튼에 SpannableStringBuilder를 설정하여 텍스트를 업데이트합니다.

// 버튼에 SpannableStringBuilder를 설정하여 텍스트를 업데이트합니다.
        myButton.text = builder

        val editTextDate1 = findViewById<EditText>(R.id.buy_date)
        val editTextDate2 = findViewById<EditText>(R.id.use_date)
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        editTextDate1.setOnClickListener {
            val datePickerDialog = DatePickerDialog(
                this,
                { view, year, month, dayOfMonth ->
                    val selectedDate = "$year-${month + 1}-$dayOfMonth"
                    editTextDate1.setText(selectedDate)
                },
                year, month, day
            )
            datePickerDialog.show()
        }

        editTextDate2.setOnClickListener {
            val datePickerDialog = DatePickerDialog(
                this,
                DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
                    val selectedDate = "$year-${month + 1}-$dayOfMonth"
                    editTextDate2.setText(selectedDate)
                },
                year, month, day
            )
            datePickerDialog.show()
        }
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.btnPhoto -> {
                // 카메라 앱을 시작하는 Intent 생성
                val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

                // 카메라 앱이 설치되어 있는지 확인
                if (takePictureIntent.resolveActivity(packageManager) != null) {
                    // 이미지를 저장할 임시 파일 생성 (선택사항)
                    val photoFile: File? = createImageFile()

                    // 임시 파일이 생성되었으면 해당 파일의 URI를 Intent에 추가
                    photoFile?.let {
                        val photoURI = FileProvider.getUriForFile(
                            this,
                            "com.example.refrigerator_202031079.fileprovider",
                            it
                        )
                        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    }

                    // 카메라 앱 실행
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
                }
            }
        }
    }

    private fun createImageFile(): File? {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "JPEG_${timeStamp}_",
            ".jpg",
            storageDir
        ).apply {
            currentPhotoPath = absolutePath
        }
    }

    companion object {
        const val REQUEST_IMAGE_CAPTURE = 1
        var currentPhotoPath: String? = null
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // 카메라 촬영을 하면 이미지뷰에 사진 삽입
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == Activity.RESULT_OK) {
            // 카메라로 촬영한 이미지를 ImageView에 표시 (ImageView의 ID를 적절히 변경하세요)
            val imageView = findViewById<ImageView>(R.id.imageView)

            // currentPhotoPath에 저장된 이미지 경로를 사용하여 이미지를 설정
            val imageFile = File(currentPhotoPath)
            val bitmap = BitmapFactory.decodeFile(imageFile.absolutePath)
            imageView.setImageBitmap(bitmap)
        }
    }
}

